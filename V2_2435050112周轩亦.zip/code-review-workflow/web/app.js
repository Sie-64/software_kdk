const form = document.querySelector("#requirementForm");
const requirementInput = document.querySelector("#requirement");
const charCount = document.querySelector("#charCount");
const runButton = document.querySelector("#runButton");
const runButtonText = document.querySelector("#runButtonText");
const runPanel = document.querySelector("#runPanel");
const newRunButton = document.querySelector("#newRunButton");
const copyCodeButton = document.querySelector("#copyCodeButton");
const downloadCodeButton = document.querySelector("#downloadCodeButton");
const codeEmpty = document.querySelector("#codeEmpty");
const codeView = document.querySelector("#codeView");
const codeContent = document.querySelector("#codeContent");
const reviewEmpty = document.querySelector("#reviewEmpty");
const reviewContent = document.querySelector("#reviewContent");
const reviewSummary = document.querySelector("#reviewSummary");
const severityStats = document.querySelector("#severityStats");
const issueList = document.querySelector("#issueList");
const issueCount = document.querySelector("#issueCount");
const liveStatus = document.querySelector(".live-status");
const liveStatusTitle = document.querySelector("#liveStatusTitle");
const liveStatusText = document.querySelector("#liveStatusText");
const iterationBadge = document.querySelector("#iterationBadge");
const durationBadge = document.querySelector("#durationBadge");
const modelBadge = document.querySelector("#modelBadge");
const runResult = document.querySelector("#runResult");
const runResultText = document.querySelector("#runResultText");
const serverStatus = document.querySelector("#serverStatus");
const serverStatusText = document.querySelector("#serverStatusText");
const toast = document.querySelector("#toast");

const stageElements = new Map(
  [...document.querySelectorAll(".agent-stage")].map((stage) => [stage.dataset.agent, stage]),
);

const AGENT_COPY = {
  coder: {
    startTitle: "Coder 正在编写初版代码",
    startText: "正在把需求转换成完整、可运行的 JavaScript 模块…",
    done: "初版代码已生成",
  },
  reviewer: {
    startTitle: "Reviewer 正在进行代码审查",
    startText: "正在检查正确性、边界条件、安全风险与可维护性…",
    done: "审查完成",
  },
  fixer: {
    startTitle: "Fixer 正在逐项修复",
    startText: "正在根据问题清单更新代码，完成后会自动回流复检…",
    done: "修复已完成",
  },
};

let finalCode = "";
let latestIssues = [];
let running = false;
let startedAt = 0;
let timerId = null;
let toastTimer = null;
let terminalEventSeen = false;

/**
 * 显示短暂的页面提示。
 *
 * @param {string} message - 提示内容。
 * @returns {void}
 */
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 2800);
}

/**
 * 将毫秒格式化成 mm:ss。
 *
 * @param {number} milliseconds - 毫秒数。
 * @returns {string} 时间文本。
 */
function formatDuration(milliseconds) {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}

/**
 * 更新运行计时器。
 *
 * @returns {void}
 */
function updateTimer() {
  durationBadge.textContent = formatDuration(Date.now() - startedAt);
}

/**
 * 切换运行状态和按钮文案。
 *
 * @param {boolean} isRunning - 是否正在运行。
 * @returns {void}
 */
function setRunning(isRunning) {
  running = isRunning;
  runButton.disabled = isRunning;
  runButton.classList.toggle("is-running", isRunning);
  runButtonText.textContent = isRunning ? "Agent 团队工作中" : "启动多 Agent 审查";
  form.setAttribute("aria-busy", String(isRunning));

  if (isRunning) {
    startedAt = Date.now();
    durationBadge.textContent = "00:00";
    window.clearInterval(timerId);
    timerId = window.setInterval(updateTimer, 500);
  } else {
    window.clearInterval(timerId);
    timerId = null;
  }
}

/**
 * 设置某个 Agent 卡片的视觉状态。
 *
 * @param {string} agentName - coder / reviewer / fixer。
 * @param {"running"|"done"|"error"|"idle"} status - 状态。
 * @param {string} [label] - 卡片状态文案。
 * @returns {void}
 */
function setAgentState(agentName, status, label) {
  const element = stageElements.get(agentName);
  if (!element) return;
  element.dataset.state = status;
  const statusElement = element.querySelector("[data-stage-status]");
  if (statusElement && label) statusElement.textContent = label;
}

/**
 * 重置流程和结果区域。
 *
 * @returns {void}
 */
function resetWorkflow() {
  terminalEventSeen = false;
  finalCode = "";
  latestIssues = [];
  durationBadge.textContent = "00:00";
  iterationBadge.textContent = "第 0 轮";
  modelBadge.textContent = "AI Agent";

  setAgentState("coder", "idle", "等待开始");
  setAgentState("reviewer", "idle", "等待开始");
  setAgentState("fixer", "idle", "按需启动");

  liveStatus.classList.remove("is-done", "is-error");
  liveStatusTitle.textContent = "正在启动 Agent 团队";
  liveStatusText.textContent = "正在连接模型并初始化审查工作流…";

  codeEmpty.hidden = false;
  codeView.hidden = true;
  codeContent.textContent = "";
  copyCodeButton.disabled = true;
  downloadCodeButton.disabled = true;

  reviewEmpty.hidden = false;
  reviewContent.hidden = true;
  reviewSummary.textContent = "";
  severityStats.replaceChildren();
  issueList.replaceChildren();
  issueCount.className = "review-count";
  issueCount.textContent = "等待中";

  runResult.className = "run-result";
  runResultText.textContent = "Agent 团队正在协作…";
}

/**
 * 更新代码预览。
 *
 * @param {string} code - 代码正文。
 * @returns {void}
 */
function updateCode(code) {
  finalCode = typeof code === "string" ? code : "";
  if (!finalCode.trim()) return;
  codeContent.textContent = finalCode;
  codeEmpty.hidden = true;
  codeView.hidden = false;
  copyCodeButton.disabled = false;
  downloadCodeButton.disabled = false;
}

/**
 * 创建严重度统计标签。
 *
 * @param {Array<Record<string, any>>} issues - 问题列表。
 * @returns {void}
 */
function renderSeverityStats(issues) {
  const labels = { high: "高优先级", medium: "中优先级", low: "低优先级" };
  severityStats.replaceChildren();

  for (const severity of ["high", "medium", "low"]) {
    const count = issues.filter((issue) => issue.severity === severity).length;
    const element = document.createElement("span");
    element.className = `severity-stat ${severity}`;
    const dot = document.createElement("i");
    element.append(dot, document.createTextNode(`${labels[severity]} ${count}`));
    severityStats.append(element);
  }
}

/**
 * 创建单条审查问题卡片。
 *
 * @param {Record<string, any>} issue - 规范化后的问题。
 * @param {number} index - 序号。
 * @returns {HTMLElement} 问题卡片。
 */
function createIssueCard(issue, index) {
  const severity = ["high", "medium", "low"].includes(issue.severity) ? issue.severity : "medium";
  const card = document.createElement("article");
  card.className = "issue-card";

  const top = document.createElement("div");
  top.className = "issue-card-top";
  const severityLabel = document.createElement("span");
  severityLabel.className = `severity-pill ${severity}`;
  severityLabel.textContent = severity.toUpperCase();
  const location = document.createElement("span");
  location.className = "issue-location";
  location.textContent = issue.location || `问题 ${index + 1}`;
  top.append(severityLabel, location);

  const description = document.createElement("h4");
  description.textContent = issue.description || "审查 Agent 未提供详细描述。";
  const suggestion = document.createElement("p");
  suggestion.className = "issue-suggestion";
  suggestion.textContent = issue.suggestion || "建议结合上下文进一步确认。";

  card.append(top, description, suggestion);
  return card;
}

/**
 * 渲染审查报告。
 *
 * @param {Record<string, any>|null} report - Reviewer 产出的报告。
 * @param {boolean} [degraded=false] - Reviewer 是否因 JSON 解析失败而降级。
 * @returns {void}
 */
function renderReview(report, degraded = false) {
  const safeReport = report && typeof report === "object" ? report : {};
  const issues = Array.isArray(safeReport.issues) ? safeReport.issues : [];
  latestIssues = issues;

  reviewEmpty.hidden = true;
  reviewContent.hidden = false;
  reviewSummary.textContent = safeReport.summary || "本轮审查未提供总体评价。";
  renderSeverityStats(issues);
  issueList.replaceChildren();

  if (issues.length === 0) {
    issueCount.className = degraded ? "review-count has-issues" : "review-count is-clean";
    issueCount.textContent = degraded ? "结果待确认" : "审查通过";
    const clean = document.createElement("div");
    clean.className = degraded ? "review-clean is-warning" : "review-clean";
    const icon = document.createElement("span");
    icon.className = "clean-icon";
    icon.textContent = degraded ? "!" : "✓";
    const title = document.createElement("strong");
    title.textContent = degraded ? "自动审查未能完成" : "本轮未发现需要修复的问题";
    const copy = document.createElement("p");
    copy.textContent = degraded
      ? "Reviewer 的输出无法解析，本次「无问题」结果不可作为审查通过依据，请人工确认。"
      : "代码已通过当前 Review Agent 的自动检查，仍建议在交付前结合测试用例人工确认。";
    clean.append(icon, title, copy);
    issueList.append(clean);
    return;
  }

  issueCount.className = "review-count has-issues";
  issueCount.textContent = `${issues.length} 项待处理`;
  issues.forEach((issue, index) => issueList.append(createIssueCard(issue, index)));
}

/**
 * 处理 Workflow 流中的单个事件。
 *
 * @param {Record<string, any>} event - 后端推送的结构化事件。
 * @returns {void}
 */
function handleWorkflowEvent(event) {
  switch (event.type) {
    case "run:accepted":
      modelBadge.textContent = event.model || "AI Agent";
      liveStatusTitle.textContent = "Agent 团队已就绪";
      liveStatusText.textContent = "正在分析需求并规划实现…";
      break;

    case "workflow:start":
      liveStatusTitle.textContent = "Workflow 已启动";
      liveStatusText.textContent = "Coder 即将开始生成第一版实现。";
      break;

    case "node:start": {
      const copy = AGENT_COPY[event.node];
      if (!copy) break;
      setAgentState(event.node, "running", "正在执行");
      liveStatusTitle.textContent = copy.startTitle;
      liveStatusText.textContent = copy.startText;
      break;
    }

    case "node:retry":
      showToast(`${event.node} 首次执行遇到问题，正在自动重试。`);
      liveStatusTitle.textContent = "节点自动重试中";
      liveStatusText.textContent = event.message || "正在重新执行当前节点…";
      break;

    case "node:error":
      setAgentState(event.node, "error", "执行失败");
      liveStatus.classList.add("is-error");
      liveStatusTitle.textContent = `${event.node} 执行失败`;
      liveStatusText.textContent = event.message || "请检查服务端日志和 API 配置。";
      break;

    case "node:done":
      if (event.state) {
        updateCode(event.state.code);
        iterationBadge.textContent = `第 ${event.state.iteration || 0} 轮`;
        if (event.state.reviewReport) {
          renderReview(event.state.reviewReport, Boolean(event.degradedReview));
        }
      }
      if (event.node === "reviewer") {
        const count = event.state?.issues?.length || 0;
        setAgentState(
          "reviewer",
          "done",
          event.degradedReview
            ? "结果需确认"
            : count === 0
              ? "未发现问题"
              : `发现 ${count} 项问题`,
        );
        if (event.degradedReview) {
          liveStatusTitle.textContent = "审查结果需要人工确认";
          liveStatusText.textContent = "Reviewer 返回的结构化结果无法解析，不能据此判定代码已通过。";
        } else if (count > 0) {
          liveStatusTitle.textContent = "需要进入修复阶段";
          liveStatusText.textContent = `Reviewer 发现 ${count} 项问题，Fixer 将逐项处理。`;
        }
      } else {
        setAgentState(
          event.node,
          "done",
          AGENT_COPY[event.node]?.done || "已完成",
        );
      }
      break;

    case "workflow:end":
      if (event.status === "done") {
        liveStatus.classList.add("is-done");
        liveStatusTitle.textContent = "工作流执行完成";
        liveStatusText.textContent = "最终代码与审查报告已经整理完成。";
      }
      break;

    case "run:completed":
      terminalEventSeen = true;
      finishRun(event);
      break;

    case "run:failed":
      terminalEventSeen = true;
      finishWithError(event.message || "Workflow 执行失败。", event.durationMs);
      break;

    default:
      break;
  }
}

/**
 * 完成一次正常运行并展示最终摘要。
 *
 * @param {Record<string, any>} event - run:completed 事件。
 * @returns {void}
 */
function finishRun(event) {
  const result = event.result || {};
  const status = event.status || result.status;
  const issues = result.reviewReport?.issues || [];

  updateCode(result.code);
  renderReview(result.reviewReport, Boolean(result.degradedReview));
  iterationBadge.textContent = `第 ${result.iteration || 0} 轮`;
  modelBadge.textContent = result.model || "AI Agent";
  if (typeof result.durationMs === "number") {
    durationBadge.textContent = formatDuration(result.durationMs);
  }

  if (status === "failed") {
    finishWithError(result.error || "Workflow 未正常完成。", result.durationMs);
    return;
  }

  liveStatus.classList.remove("is-error");
  liveStatus.classList.add("is-done");
  if (result.degradedReview) {
    liveStatusTitle.textContent = "审查结束，但结果需要人工确认";
    liveStatusText.textContent = "结构化审查结果解析失败，本次不能判定为审查通过。";
    runResult.className = "run-result is-warning";
    runResultText.textContent = "自动审查结果不可用 · 请查看执行日志并人工确认代码";
  } else if (issues.length === 0) {
    liveStatusTitle.textContent = "审查完成，代码状态良好";
    liveStatusText.textContent = "Reviewer 未发现需要进入修复流程的问题。";
    runResult.className = "run-result is-success";
    runResultText.textContent = `审查通过 · ${result.iteration || 0} 轮修复 · ${result.snapshotCount || 0} 次状态快照`;
  } else {
    liveStatusTitle.textContent = "已达到当前审查上限";
    liveStatusText.textContent = `仍有 ${issues.length} 项问题，请在交付前人工确认修复建议。`;
    runResult.className = "run-result is-warning";
    runResultText.textContent = `审查完成，但仍有 ${issues.length} 项问题 · 已完成 ${result.iteration || 0} 轮修复`;
  }
}

/**
 * 处理运行错误。
 *
 * @param {string} message - 错误信息。
 * @param {number} [durationMs] - 已运行时长。
 * @returns {void}
 */
function finishWithError(message, durationMs) {
  liveStatus.classList.remove("is-done");
  liveStatus.classList.add("is-error");
  liveStatusTitle.textContent = "运行未完成";
  liveStatusText.textContent = message;
  runResult.className = "run-result is-error";
  runResultText.textContent = "请修正配置或稍后重新发起审查。";
  if (typeof durationMs === "number") durationBadge.textContent = formatDuration(durationMs);
  showToast(message);
}

/**
 * 读取 NDJSON 响应并逐行处理。
 *
 * @param {Response} response - fetch 响应。
 * @returns {Promise<void>} 响应消费完成后的 Promise。
 */
async function consumeWorkflowStream(response) {
  if (!response.body) throw new Error("浏览器无法读取流式响应。");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  const processLine = (line) => {
    const trimmed = line.trim();
    if (!trimmed) return;
    try {
      handleWorkflowEvent(JSON.parse(trimmed));
    } catch {
      throw new Error("服务端返回了无法解析的进度数据。");
    }
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    lines.forEach(processLine);
  }

  buffer += decoder.decode();
  if (buffer.trim()) processLine(buffer);
}

/**
 * 表单提交：启动一次完整 Workflow。
 *
 * @param {SubmitEvent} event - 表单提交事件。
 * @returns {Promise<void>} 请求完成后 resolve。
 */
async function startRun(event) {
  event.preventDefault();
  if (running) return;

  const requirement = requirementInput.value.trim();
  if (requirement.length < 8) {
    requirementInput.focus();
    showToast("请至少输入 8 个字符，清楚描述要实现的功能。");
    return;
  }

  resetWorkflow();
  runPanel.hidden = false;
  setRunning(true);
  window.setTimeout(() => runPanel.scrollIntoView({ behavior: "smooth", block: "start" }), 40);

  try {
    const response = await fetch("/api/runs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ requirement }),
    });

    if (!response.ok) {
      let message = `请求失败（HTTP ${response.status}）。`;
      try {
        const payload = await response.json();
        if (payload?.error) message = payload.error;
      } catch {
        // 保留通用 HTTP 错误信息
      }
      throw new Error(message);
    }

    await consumeWorkflowStream(response);
    if (!terminalEventSeen) throw new Error("与服务端的连接提前中断，请重新运行。");
  } catch (error) {
    terminalEventSeen = true;
    finishWithError(error?.message || "无法连接审查服务。", Date.now() - startedAt);
  } finally {
    setRunning(false);
  }
}

/**
 * 检查服务端 API Key 配置状态。
 *
 * @returns {Promise<void>} 检查完成后的 Promise。
 */
async function checkServerHealth() {
  serverStatus.className = "server-status is-loading";
  serverStatusText.textContent = "正在连接服务";

  try {
    const response = await fetch("/api/health", { cache: "no-store" });
    if (!response.ok) throw new Error("服务不可用");
    const health = await response.json();

    if (health.ready) {
      serverStatus.className = "server-status is-ready";
      serverStatusText.textContent = "服务已连接";
      serverStatus.title = `模型：${health.model}，最多 ${health.maxIterations} 轮修复`;
      modelBadge.textContent = health.model || "AI Agent";
    } else {
      serverStatus.className = "server-status is-error";
      serverStatusText.textContent = "待配置 API Key";
      serverStatus.title = health.message || "请检查 .env 配置";
    }
  } catch {
    serverStatus.className = "server-status is-error";
    serverStatusText.textContent = "服务未连接";
    serverStatus.title = "请通过 npm run web 启动 Web 服务";
  }
}

form.addEventListener("submit", startRun);

requirementInput.addEventListener("input", () => {
  charCount.textContent = `${requirementInput.value.length} / 12000`;
});

requirementInput.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll(".prompt-chip").forEach((button) => {
  button.addEventListener("click", () => {
    requirementInput.value = button.dataset.prompt || "";
    charCount.textContent = `${requirementInput.value.length} / 12000`;
    requirementInput.focus();
    requirementInput.setSelectionRange(
      requirementInput.value.length,
      requirementInput.value.length,
    );
  });
});

copyCodeButton.addEventListener("click", async () => {
  if (!finalCode) return;
  try {
    await navigator.clipboard.writeText(finalCode);
    showToast("最终代码已复制到剪贴板。");
  } catch {
    showToast("复制失败，请手动选择代码。");
  }
});

downloadCodeButton.addEventListener("click", () => {
  if (!finalCode) return;
  const blob = new Blob([`${finalCode}\n`], { type: "text/javascript;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "generated.js";
  link.click();
  URL.revokeObjectURL(url);
  showToast("最终代码已开始下载。");
});

newRunButton.addEventListener("click", () => {
  if (running) return;
  runPanel.hidden = true;
  document.querySelector("#studio").scrollIntoView({ behavior: "smooth", block: "start" });
  window.setTimeout(() => requirementInput.focus(), 450);
});

checkServerHealth();
