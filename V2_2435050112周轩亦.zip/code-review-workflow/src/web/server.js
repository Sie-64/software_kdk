/**
 * @file server.js
 * @description 本地 Web 界面服务：提供静态页面，并以 NDJSON 流实时推送 Workflow 进度。
 *              API Key 只从服务端 `.env` 读取，不会发送到浏览器。
 */

import http from "node:http";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { readFile, stat } from "node:fs/promises";
import { fileURLToPath } from "node:url";

import { loadConfig, validateConfig } from "../config.js";
import { MessageBus } from "../workflow/messageBus.js";
import { WorkflowState } from "../workflow/state.js";
import { createNodes } from "../workflow/nodes.js";
import { createFlow } from "../workflow/flows.js";
import { Orchestrator, WorkflowLogger } from "../workflow/orchestrator.js";

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(currentDir, "../..");
const webRoot = path.join(projectRoot, "web");
const host = process.env.WEB_HOST || "127.0.0.1";
const requestedPort = Number.parseInt(process.env.WEB_PORT || "3000", 10);
const port = Number.isInteger(requestedPort) && requestedPort > 0 ? requestedPort : 3000;
const maxBodyBytes = 64 * 1024;
const maxRequirementLength = 12_000;

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

/**
 * 设置所有静态与 API 响应通用的安全头。
 *
 * @param {http.ServerResponse} res - HTTP 响应。
 * @returns {void}
 */
function setSecurityHeaders(res) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; frame-ancestors 'none';",
  );
}

/**
 * 发送 JSON 响应。
 *
 * @param {http.ServerResponse} res - HTTP 响应。
 * @param {number} statusCode - HTTP 状态码。
 * @param {Record<string, any>} payload - JSON 数据。
 * @returns {void}
 */
function sendJson(res, statusCode, payload) {
  if (res.writableEnded) return;
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
  });
  res.end(body);
}

/**
 * 读取并限制 JSON 请求体大小。
 *
 * @param {http.IncomingMessage} req - HTTP 请求。
 * @returns {Promise<Record<string, any>>} 解析后的对象。
 */
async function readJsonBody(req) {
  const chunks = [];
  let total = 0;

  for await (const chunk of req) {
    total += chunk.length;
    if (total > maxBodyBytes) {
      const error = new Error("请求内容过大。");
      error.statusCode = 413;
      throw error;
    }
    chunks.push(chunk);
  }

  if (chunks.length === 0) return {};

  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString("utf-8"));
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    const error = new Error("请求体不是合法 JSON。");
    error.statusCode = 400;
    throw error;
  }
}

/**
 * 获取可安全展示给前端的配置状态，不返回 API Key。
 *
 * @returns {{ready: boolean, model: string, maxIterations: number, message?: string}} 配置状态。
 */
function getPublicHealth() {
  const config = loadConfig();
  try {
    validateConfig(config);
    return {
      ready: true,
      model: config.model,
      maxIterations: config.maxIterations,
    };
  } catch {
    return {
      ready: false,
      model: config.model,
      maxIterations: config.maxIterations,
      message: "服务端尚未配置有效的 OPENAI_API_KEY，请检查项目根目录的 .env。",
    };
  }
}

/**
 * 创建一次 Workflow 运行，并通过 NDJSON 持续推送进度。
 *
 * @param {http.IncomingMessage} req - HTTP 请求。
 * @param {http.ServerResponse} res - HTTP 响应。
 * @returns {Promise<void>} 流结束后的 Promise。
 */
async function handleRun(req, res) {
  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    sendJson(res, err.statusCode || 400, { error: err.message });
    return;
  }

  const requirement = typeof body.requirement === "string" ? body.requirement.trim() : "";
  if (requirement.length < 8) {
    sendJson(res, 400, { error: "请至少输入 8 个字符，清楚描述要实现的功能。" });
    return;
  }
  if (requirement.length > maxRequirementLength) {
    sendJson(res, 400, { error: `需求不能超过 ${maxRequirementLength} 个字符。` });
    return;
  }

  let config;
  try {
    config = loadConfig();
    validateConfig(config);
  } catch {
    sendJson(res, 503, {
      error: "服务端尚未配置有效的 API Key。请打开项目根目录的 .env，填写 OPENAI_API_KEY 后重启 Web 服务。",
    });
    return;
  }

  const runId = randomUUID();
  const startedAt = Date.now();
  const emit = (event) => {
    if (res.destroyed || res.writableEnded) return;
    try {
      res.write(`${JSON.stringify(event)}\n`);
    } catch {
      // 浏览器刷新或断开时停止推送，但不影响已开始的 Workflow。
    }
  };

  res.writeHead(200, {
    "Content-Type": "application/x-ndjson; charset=utf-8",
    "Cache-Control": "no-store, no-transform",
    "X-Accel-Buffering": "no",
  });
  emit({ type: "run:accepted", runId, model: config.model, timestamp: Date.now() });

  const state = new WorkflowState();
  state.set("requirement", requirement);
  state.set("iteration", 0);

  const messageBus = new MessageBus();
  const logger = new WorkflowLogger({
    dir: path.join(projectRoot, "logs"),
    verbose: false,
    echo: false,
  });
  let reviewDegraded = false;
  messageBus.subscribe("reviewer:done", (message) => {
    if (message.payload?.degraded) reviewDegraded = true;
  });
  const nodes = createNodes({ config, messageBus });
  const flow = createFlow(config);

  try {
    const orchestrator = new Orchestrator({
      nodes,
      flow,
      state,
      messageBus,
      logger,
      onEvent: (event) => {
        emit(
          event.type === "node:done" && event.node === "reviewer"
            ? { ...event, degradedReview: reviewDegraded }
            : event,
        );
      },
    });
    const result = await orchestrator.run();
    const completedState = result.toJSON();
    emit({
      type: "run:completed",
      runId,
      status: completedState.status,
      result: {
        code: completedState.code ?? "",
        reviewReport: completedState.reviewReport ?? null,
        iteration: completedState.iteration ?? 0,
        error: completedState.error ?? null,
        maxIterations: config.maxIterations,
        model: config.model,
        durationMs: Date.now() - startedAt,
        messageCount: messageBus.getHistory().length,
        snapshotCount: result.getSnapshots().length,
        logPath: logger.getFilePath(),
        degradedReview: reviewDegraded,
      },
    });
  } catch (err) {
    emit({
      type: "run:failed",
      runId,
      message: err?.message || "Workflow 执行失败。",
      durationMs: Date.now() - startedAt,
    });
  } finally {
    if (!res.writableEnded) res.end();
  }
}

/**
 * 安全地解析并返回 Web 目录内静态文件。
 *
 * @param {string} pathname - 请求路径。
 * @param {http.ServerResponse} res - HTTP 响应。
 * @returns {Promise<void>} 文件发送完成后的 Promise。
 */
async function serveStatic(pathname, res) {
  const relativePath = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const filePath = path.resolve(webRoot, relativePath);

  if (filePath !== webRoot && !filePath.startsWith(`${webRoot}${path.sep}`)) {
    sendJson(res, 403, { error: "禁止访问该路径。" });
    return;
  }

  try {
    const fileStat = await stat(filePath);
    if (!fileStat.isFile()) throw new Error("not a file");
    const content = await readFile(filePath);
    res.writeHead(200, {
      "Content-Type": MIME_TYPES[path.extname(filePath).toLowerCase()] || "application/octet-stream",
      "Content-Length": content.length,
      "Cache-Control": "no-cache",
    });
    res.end(content);
  } catch {
    sendJson(res, 404, { error: "页面不存在。" });
  }
}

const server = http.createServer(async (req, res) => {
  setSecurityHeaders(res);
  const url = new URL(req.url || "/", `http://${req.headers.host || `${host}:${port}`}`);

  try {
    if (req.method === "GET" && url.pathname === "/api/health") {
      sendJson(res, 200, getPublicHealth());
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/runs") {
      await handleRun(req, res);
      return;
    }

    if (url.pathname.startsWith("/api/")) {
      sendJson(res, 404, { error: "API 不存在。" });
      return;
    }

    if (req.method === "GET" || req.method === "HEAD") {
      await serveStatic(decodeURIComponent(url.pathname), res);
      return;
    }

    sendJson(res, 405, { error: "不支持的请求方法。" });
  } catch (err) {
    console.error("[web] 请求处理失败：", err);
    if (!res.headersSent) {
      sendJson(res, 500, { error: "服务器内部错误。" });
    } else if (!res.writableEnded) {
      res.end();
    }
  }
});

server.listen(port, host, () => {
  console.log(`\n  Code Review Studio 已启动：http://${host}:${port}`);
  console.log("  按 Ctrl+C 停止服务。\n");
});

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(
      `\n  端口 ${port} 已被占用。请先停止占用该端口的服务，或换一个端口启动：\n` +
        `  WEB_PORT=3001 npm run dev\n`,
    );
    process.exitCode = 1;
    return;
  }

  console.error(`\n  Web 服务启动失败：${err.message}\n`);
  process.exitCode = 1;
});
